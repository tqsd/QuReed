"""
Expansion levels
"""

from enum import Enum


class ExpansionLevel:
    Label = 0
    Vector = 1
    Matrix = 2
