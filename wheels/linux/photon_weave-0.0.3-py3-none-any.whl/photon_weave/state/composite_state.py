"""
PhotonWeave Composite state
"""

class CompositeState:
    pass
