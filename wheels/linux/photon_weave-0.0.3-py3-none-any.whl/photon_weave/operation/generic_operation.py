from abc import ABC


class GenericOperation(ABC):
    pass
