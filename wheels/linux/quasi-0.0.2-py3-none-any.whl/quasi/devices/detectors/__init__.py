from .ideal_detector import IdealDetector
