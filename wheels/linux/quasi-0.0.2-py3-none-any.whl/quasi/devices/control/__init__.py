from .simple_trigger import SimpleTrigger
from .clock_trigger import ClockTrigger
