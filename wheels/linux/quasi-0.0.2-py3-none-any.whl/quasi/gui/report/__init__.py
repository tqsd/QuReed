from .report import Report
from .report import GuiLogHandler
