"""
Constants available for quasi
"""

C = 299792458
