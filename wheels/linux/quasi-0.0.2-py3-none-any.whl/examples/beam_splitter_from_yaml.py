from quasi.simulation import Simulation

S = Simulation(yml="./beam_splitter.yml")

S.run()

